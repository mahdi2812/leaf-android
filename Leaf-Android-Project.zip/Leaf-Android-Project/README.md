# Leaf — Android project

A native Android shell around the Leaf EPUB reader web app. No Capacitor,
no Cordova — just a single Activity hosting a WebView, so there's no
app-framework minimum-SDK ceiling to fight. minSdk 21 (Android 5.0).

## What's inside
- `app/src/main/java/com/leaf/reader/MainActivity.kt` — the native shell.
  Loads the app through `WebViewAssetLoader` (a virtual `https://` origin)
  rather than a raw `file://` URL, so IndexedDB/localStorage behave the
  same way they would on a normal website.
- `app/src/main/assets/www/` — your Leaf web app. `epub.js` and `jszip`
  are bundled locally (no CDN calls, works fully offline). epub.js is the
  `legacy` build variant, which is transpiled/polyfilled for older
  browser engines instead of only the last 2 versions of Chrome.
- No `INTERNET` permission — the app never needs the network.

## Changes made to your original code
- CDN `<script>` tags → local files in `assets/www/lib/`.
- `epub.min.js` → `epub.legacy.min.js` (broader browser-engine compatibility).
- CSS `aspect-ratio` (unsupported on older WebView engines) → the classic
  padding-based aspect-ratio technique, which works everywhere.
- CSS `inset` shorthand (same compatibility concern, and used for major
  full-screen layout) → explicit `top/right/bottom/left`.
- `book.locations.generate(1200)` → `generate(3000)`, to cut background
  CPU work when a book is opened (epub.js's own example uses 1600; higher
  means fewer location breakpoints to compute, at the cost of slightly
  coarser progress-percentage granularity — not visually noticeable).

## To build the APK
1. Open this folder (`native/`) in Android Studio — "Open" not "Import",
   point it at this directory. Let Gradle sync (Android Studio will offer
   to generate the wrapper jar automatically if it's missing).
2. Build → Build Bundle(s) / APK(s) → Build APK(s). Or from a terminal
   once the wrapper exists: `./gradlew assembleDebug`.
3. The APK lands in `app/build/outputs/apk/debug/`.

For a real Android 5 device, test the debug APK directly (`adb install`,
or copy it to the device). For anything beyond personal testing, you'll
want a signed release build — Android Studio's Build > Generate Signed
Bundle/APK handles that.

## Before you rely on this for real Android 5 hardware
- `compileSdk`/`targetSdk` are set to 36; Android Studio will prompt to
  install SDK Platform 36 if it isn't already on your machine.
- `applicationId` is a placeholder (`com.leaf.reader`) — change it in
  `app/build.gradle` before publishing anywhere.
- Test on an actual old device or an API 21 emulator image if you can —
  I can't run or render this in the environment I built it in, so the
  compatibility choices above are well-reasoned but not test-verified
  end-to-end.
