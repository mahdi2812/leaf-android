package com.leaf.reader

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewAssetLoader

/**
 * Single-Activity native shell for the Leaf EPUB reader.
 *
 * Deliberately does NOT use Capacitor or Cordova: current versions of both
 * require Android 7 (API 24) or newer, which would silently break on real
 * Android 5 devices even if the Gradle minSdk number were forced down.
 * This Activity uses only the plain Android WebView + androidx.webkit,
 * both of which support API 21 directly, so there's no framework floor to
 * fight.
 */
class MainActivity : Activity() {

    private lateinit var webView: WebView
    private var pendingFileCallback: ValueCallback<Array<Uri>>? = null

    companion object {
        private const val FILE_CHOOSER_REQUEST_CODE = 51426
        private const val APP_URL = "https://appassets.androidplatform.net/assets/www/index.html"
    }

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        webView = WebView(this)
        setContentView(webView)

        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            cacheMode = android.webkit.WebSettings.LOAD_DEFAULT
        }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? = assetLoader.shouldInterceptRequest(request.url)
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView,
                filePathCallback: ValueCallback<Array<Uri>>,
                fileChooserParams: FileChooserParams
            ): Boolean {
                pendingFileCallback?.onReceiveValue(null)
                pendingFileCallback = filePathCallback
                return try {
                    startActivityForResult(fileChooserParams.createIntent(), FILE_CHOOSER_REQUEST_CODE)
                    true
                } catch (e: Exception) {
                    pendingFileCallback = null
                    false
                }
            }
        }

        webView.loadUrl(APP_URL)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == FILE_CHOOSER_REQUEST_CODE) {
            val results = WebChromeClient.FileChooserParams.parseResult(resultCode, data)
            pendingFileCallback?.onReceiveValue(results)
            pendingFileCallback = null
        } else {
            super.onActivityResult(requestCode, resultCode, data)
        }
    }

    // Ask the page to close the reader first; only exit the Activity if it
    // was already showing the library (mirrors normal reader-app back behavior).
    override fun onBackPressed() {
        webView.evaluateJavascript(
            "(function(){var r=document.getElementById('reader');" +
                "if(r&&r.classList.contains('open')){document.getElementById('backBtn').click();return 'true';}" +
                "return 'false';})()"
        ) { result ->
            if (result != "true" && result != "\"true\"") {
                super.onBackPressed()
            }
        }
    }
}
